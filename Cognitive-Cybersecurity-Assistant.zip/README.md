# Cognitive-Cybersecurity-Assistant

This folder contains Cognitive-Cybersecurity-Assistant files for the CCA project.